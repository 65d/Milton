import React from "react";
import "./style.css";

// import "../../App.css";
function Nav() {
    return (
        <div className="nav">
            <div className="logo">
                Milton
            </div>
            <hr />
            <div className="text3">
            Denali is a simple responsive blog template. Easily add new posts using the Editor or change layout and design using the Designer.
            </div>
            <hr />
        </div>
    )
}

export default Nav;