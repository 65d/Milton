import React from "react";
import "./style.css";
import Img1 from "./imgs/aerial-shot-beautiful-tree-forest-covered-with-fog-bled-slovenia.jpg";
import Img2 from "./imgs/beautiful-milky-way-night-sky.jpg";
import Img3 from "./imgs/white-painted-wall-texture-background.jpg";
import Card from "./card";

// import "../../App.css";
function Cards() {
    const cards = [
        {
            img: Img1,
            text: "Coffee variety macchiato, as organic ut variety caffeine americano",
            text2: "Saucer, crema carajillo, bar, mocha medium, latte cappuccino and espresso acerbic to go. Coffee, irish foam turkish coffee blue mountain seasonal. Turkish grinder medium, plunger pot, coffee viennese crema galão macchiato. Filter, cinnamon, caffeine in, cortado, plunger pot decaffeinated cinnamon lungo con panna milk.",
            date: "JUNE 25, 2020"

        },
        {
            img: Img2,
            text: "kdsfjk hifhds fhdsuhgdsilgh dshg dsu",
            text2: "Saucer, crema carajillo, bar, mocha medium, latte cappuccino and espresso acerbic to go. Coffee, irish foam turkish coffee blue mountain seasonal. Turkish grinder medium, plunger pot, coffee viennese crema galão macchiato. Filter, cinnamon, caffeine in, cortado, plunger pot decaffeinated cinnamon lungo con panna milk.",
            date: "JUNE 25, 2020"
        },
        {
            img: Img3,
            text: "kdsfjk hifhds fhdsuhgdsilgh dshg dsu",
            text2: "Saucer, crema carajillo, bar, mocha medium, latte cappuccino and espresso acerbic to go. Coffee, irish foam turkish coffee blue mountain seasonal. Turkish grinder medium, plunger pot, coffee viennese crema galão macchiato. Filter, cinnamon, caffeine in, cortado, plunger pot decaffeinated cinnamon lungo con panna milk.",
            date: "JUNE 25, 2020"
        }
    ]
    return (
        <div className="cards-container">
            <h1 class="white-bg-heading">All Posts</h1>
           {/* <Card image={Img1}/> */}
           {
            cards.map(
                function(el) {
                    return (
                        <Card date={el.date} text2={el.text2} text={el.text} image={el.img}/>
                    )
                }
            )
           }
        </div>
    )
}

export default Cards;