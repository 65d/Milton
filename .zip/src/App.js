import './App.css';
import Cards from './componets/cards';
import Nav from './componets/nav';

function App() {
  return (
    <div className="App">
        <Nav/>
        <Cards/>
    </div>
  );
}

export default App;
