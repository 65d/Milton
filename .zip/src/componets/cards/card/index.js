import React from "react";
import "./style.css";

// import "../../App.css";
function Card(probs) {
    return (
        <div className="card">
            <img src={probs.image} alt="" />
            <h1>
                {probs.text}
            </h1>
            <div className="p">
                {probs.text2}
            </div>
            <div className="date">
                {probs.date}
                </div>
        </div>
    )
}

export default Card;